import express from 'express'
import compression from 'compression'
import path from 'path'
import { fileURLToPath } from 'url'
import { createProxyMiddleware } from 'http-proxy-middleware'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
app.use(compression())

// ---- WB API proxy (обходит CORS) ----
app.use(
  '/wb',
  createProxyMiddleware({
    target: 'https://feedbacks-api.wildberries.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb': '',
    },
    onProxyReq: (proxyReq, req) => {
      // ВАЖНО: ключ не хранится на сервере; он приходит от браузера как Authorization header.
      // Никаких логов с ключом!
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Ads API proxy (advert-api.wildberries.ru) ----
app.use(
  '/wb-ads',
  createProxyMiddleware({
    target: 'https://advert-api.wildberries.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-ads': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Ads API proxy (альтернативный домен advert-api.wb.ru) ----
app.use(
  '/wb-ads2',
  createProxyMiddleware({
    target: 'https://advert-api.wb.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-ads2': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Media Ads API proxy (advert-media-api.wildberries.ru) ----
app.use(
  '/wb-ads-media',
  createProxyMiddleware({
    target: 'https://advert-media-api.wildberries.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-ads-media': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Media Ads API proxy (альтернативный домен advert-media-api.wb.ru) ----
app.use(
  '/wb-ads-media2',
  createProxyMiddleware({
    target: 'https://advert-media-api.wb.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-ads-media2': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Common API proxy (common-api.wildberries.ru) ----
app.use(
  '/wb-common',
  createProxyMiddleware({
    target: 'https://common-api.wildberries.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-common': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Common API proxy (альтернативный домен common-api.wb.ru) ----
app.use(
  '/wb-common2',
  createProxyMiddleware({
    target: 'https://common-api.wb.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-common2': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Content API proxy (content-api.wildberries.ru) ----
app.use(
  '/wb-content',
  createProxyMiddleware({
    target: 'https://content-api.wildberries.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-content': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Content API proxy (альтернативный домен content-api.wb.ru) ----
app.use(
  '/wb-content2',
  createProxyMiddleware({
    target: 'https://content-api.wb.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-content2': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Prices & Discounts API proxy (discounts-prices-api.wildberries.ru) ----
app.use(
  '/wb-prices',
  createProxyMiddleware({
    target: 'https://discounts-prices-api.wildberries.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-prices': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- WB Prices & Discounts API proxy (альтернативный домен discounts-prices-api.wb.ru) ----
app.use(
  '/wb-prices2',
  createProxyMiddleware({
    target: 'https://discounts-prices-api.wb.ru',
    changeOrigin: true,
    secure: true,
    pathRewrite: {
      '^/wb-prices2': '',
    },
    onProxyReq: (proxyReq) => {
      proxyReq.removeHeader('origin')
    },
  }),
)

// ---- Static фронтенд (после `npm run build`) ----
const distDir = path.resolve(__dirname, '..', 'dist')
app.use(express.static(distDir))

// SPA fallback
app.get('*', (_req, res) => {
  res.sendFile(path.join(distDir, 'index.html'))
})

const port = Number(process.env.PORT || 4173)
app.listen(port, () => {
  console.log(`WB feedbacks app running on http://localhost:${port}`)
  console.log('API proxy: /wb -> https://feedbacks-api.wildberries.ru')
  console.log('API proxy: /wb-ads -> https://advert-api.wildberries.ru')
  console.log('API proxy: /wb-ads2 -> https://advert-api.wb.ru')
  console.log('API proxy: /wb-ads-media -> https://advert-media-api.wildberries.ru')
  console.log('API proxy: /wb-ads-media2 -> https://advert-media-api.wb.ru')
  console.log('API proxy: /wb-common -> https://common-api.wildberries.ru')
  console.log('API proxy: /wb-common2 -> https://common-api.wb.ru')
  console.log('API proxy: /wb-content -> https://content-api.wildberries.ru')
  console.log('API proxy: /wb-content2 -> https://content-api.wb.ru')
  console.log('API proxy: /wb-prices -> https://discounts-prices-api.wildberries.ru')
  console.log('API proxy: /wb-prices2 -> https://discounts-prices-api.wb.ru')
})
