import { WB_COMMON_ENDPOINTS, WB_PROXY_COMMON, WB_PROXY_COMMON_ALT } from '../config'
import { wbProxyFetch } from './wbProxyFetch'

export type SellerInfo = {
  name?: string
  sid?: number
  tradeMark?: string
}

/** Получить название магазина/продавца по токену (General API). */
export async function getSellerInfo(token: string): Promise<SellerInfo> {
  const t = token.trim()
  try {
    return await wbProxyFetch<SellerInfo>(t, WB_PROXY_COMMON, WB_COMMON_ENDPOINTS.sellerInfo, {
      authMode: 'raw',
    })
  } catch (e: any) {
    // У части кабинетов/сетей может отвечать альтернативный домен.
    // 404 "Please consult ..." часто означает не тот домен/маршрут.
    const status = Number(e?.status)
    if (status === 404 || status === 0) {
      return wbProxyFetch<SellerInfo>(t, WB_PROXY_COMMON_ALT, WB_COMMON_ENDPOINTS.sellerInfo, {
        authMode: 'raw',
      })
    }
    throw e
  }
}
