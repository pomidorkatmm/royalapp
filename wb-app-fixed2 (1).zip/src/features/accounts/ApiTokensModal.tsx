import React, { useEffect, useMemo, useState } from 'react'
import { validateToken, WbHttpError } from '../../api/wbClient'
import { validateAdsToken } from '../../api/wbAdsClient'
import { getSellerInfo } from '../../api/wbCommonClient'
import { checkContentAccess } from '../../api/wbContentClient'
import { checkPricesAccess } from '../../api/wbPricesClient'
import { getMediaCampaignCount } from '../../api/wbAdsManageClient'
import type { WbAccount } from './accountsStorage'
import { useToast } from '../../components/Toast'

export default function ApiTokensModal({
  open,
  accounts,
  activeId,
  onClose,
  onSave,
  onSetActive,
}: {
  open: boolean
  accounts: WbAccount[]
  activeId: string | null
  onClose: () => void
  onSave: (next: WbAccount[]) => void
  onSetActive: (id: string) => void
}) {
  const { push } = useToast()
  const [draftAccounts, setDraftAccounts] = useState<WbAccount[]>(accounts)
  const [selectedId, setSelectedId] = useState<string | null>(activeId)

  useEffect(() => {
    if (!open) return
    setDraftAccounts(accounts)
    setSelectedId(activeId || accounts[0]?.id || null)
  }, [open, accounts, activeId])

  const selected = useMemo(() => draftAccounts.find((a) => a.id === selectedId) ?? null, [draftAccounts, selectedId])

  const setSelectedField = (patch: Partial<WbAccount>) => {
    if (!selected) return
    setDraftAccounts((prev) => prev.map((a) => (a.id === selected.id ? { ...a, ...patch } : a)))
  }

  const upsertAccount = () => {
    const id = `acc_${Date.now()}_${Math.random().toString(16).slice(2)}`
    const acc: WbAccount = { id, name: 'Новый магазин', sellerToken: '', adsToken: '' }
    setDraftAccounts((p) => [acc, ...p])
    setSelectedId(id)
  }

  const removeSelected = () => {
    if (!selected) return
    const next = draftAccounts.filter((a) => a.id !== selected.id)
    setDraftAccounts(next)
    const nextId = next[0]?.id || null
    setSelectedId(nextId)
    if (activeId === selected.id && nextId) onSetActive(nextId)
  }

  const commitAndClose = () => {
    onSave(draftAccounts)
    if (selectedId) onSetActive(selectedId)
    onClose()
  }

  function mark(hasToken: boolean, v?: boolean) {
    if (!hasToken) return '—'
    if (v === true) return '✅'
    if (v === false) return '❌'
    return '⏳'
  }

  function fmtErr(e: any) {
    return e instanceof WbHttpError ? `${e.status}: ${e.detail || e.message}` : String(e?.message ?? e)
  }

  // auto-save on click outside (по ТЗ)
  if (!open) return null

  return (
    <div
      className="modalOverlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) commitAndClose()
      }}
    >
      <div className="modal" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modalHeader">
          <div style={{ fontWeight: 800 }}>API токены</div>
          <button className="btn" onClick={commitAndClose}>
            Закрыть
          </button>
        </div>

        <div className="grid" style={{ gridTemplateColumns: '320px 1fr', marginTop: 12 }}>
          <div className="card" style={{ borderRadius: 12 }}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <div style={{ fontWeight: 700 }}>Магазины</div>
              <button className="btn" onClick={upsertAccount}>
                + Добавить
              </button>
            </div>
            <div className="list" style={{ marginTop: 10, maxHeight: '52vh', overflow: 'auto' }}>
              {draftAccounts.map((a) => (
                <div
                  key={a.id}
                  className={['campaignRow', selectedId === a.id ? 'isSelected' : ''].join(' ')}
                  onClick={() => setSelectedId(a.id)}
                >
                  <div style={{ fontWeight: 700 }}>{a.name}</div>
                  <div className="small muted" style={{ marginTop: 2 }}>
                    {mark(!!a.sellerToken, a.tokenChecks?.feedbacks)} отзывы • {mark(!!a.sellerToken, a.tokenChecks?.content)} контент • {mark(!!a.sellerToken, a.tokenChecks?.prices)} цены • {mark(!!a.adsToken, a.tokenChecks?.adsPromotion ?? a.tokenChecks?.adsMedia)} реклама
                    {activeId === a.id ? ' • (активный)' : ''}
                  </div>
                </div>
              ))}
              {draftAccounts.length === 0 && <div className="muted">Нет сохранённых магазинов</div>}
            </div>
          </div>

          <div className="card" style={{ borderRadius: 12 }}>
            {!selected ? (
              <div className="muted">Выберите магазин слева</div>
            ) : (
              <>
                <div className="row" style={{ justifyContent: 'space-between' }}>
                  <div className="row" style={{ gap: 8 }}>
                    <input
                      className="input"
                      value={selected.name}
                      onChange={(e) => setSelectedField({ name: e.target.value })}
                      placeholder="Название магазина"
                      style={{ width: 'min(520px, 90vw)' }}
                    />
                    <button
                      className="btn"
                      onClick={() => {
                        onSetActive(selected.id)
                        push('Аккаунт выбран')
                      }}
                    >
                      Сделать активным
                    </button>
                  </div>
                  <button className="btn" onClick={removeSelected}>
                    Удалить
                  </button>
                </div>

                <div className="small muted" style={{ marginTop: 8 }}>
                  Токены сохраняются локально. Закрытие окна сохраняет изменения автоматически.
                </div>

                <div className="row" style={{ marginTop: 12, gap: 10, alignItems: 'flex-start' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 800, marginBottom: 6 }}>Отзывы / контент / цены</div>
                    <textarea
                      className="textarea"
                      value={selected.sellerToken}
                      onChange={(e) => setSelectedField({ sellerToken: e.target.value })}
                      placeholder="Токен WB (Feedbacks & Questions + Content + Prices)"
                    />
                    <div className="row" style={{ marginTop: 8, gap: 8 }}>
                      <button
                        className="btn primary"
                        onClick={async () => {
                          const t = selected.sellerToken.trim()
                          const checks = {
                            ...(selected.tokenChecks ?? {}),
                            checkedAtMs: Date.now(),
                          } as NonNullable<WbAccount['tokenChecks']>

                          const errors: string[] = []

                          // 1) Отзывы (Feedbacks API)
                          try {
                            await validateToken(t)
                            checks.feedbacks = true
                          } catch (e: any) {
                            checks.feedbacks = false
                            errors.push(`Отзывы: ${fmtErr(e)}`)
                          }

                          // 2) Контент (Content API)
                          try {
                            await checkContentAccess(t)
                            checks.content = true
                          } catch (e: any) {
                            checks.content = false
                            errors.push(`Контент: ${fmtErr(e)}`)
                          }

                          // 3) Цены (Prices&Discounts API)
                          try {
                            await checkPricesAccess(t)
                            checks.prices = true
                          } catch (e: any) {
                            checks.prices = false
                            errors.push(`Цены: ${fmtErr(e)}`)
                          }

                          // 4) Название магазина (не влияет на валидность)
                          try {
                            const info = await getSellerInfo(t)
                            const newName = String(info?.tradeMark || info?.name || selected.name || 'Магазин')
                            setSelectedField({ name: newName, sellerSid: info?.sid, tokenChecks: checks })
                          } catch {
                            setSelectedField({ tokenChecks: checks })
                          }

                          const parts: string[] = []
                          parts.push(`${checks.feedbacks ? '✅' : '❌'} отзывы`)
                          parts.push(`${checks.content ? '✅' : '❌'} контент`)
                          parts.push(`${checks.prices ? '✅' : '❌'} цены`)
                          push(parts.join(' • '))
                          if (errors.length > 0) {
                            push(errors.slice(0, 2).join(' | '))
                          }
                        }}
                        disabled={!selected.sellerToken.trim()}
                      >
                        Проверить
                      </button>
                    </div>
                  </div>

                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 800, marginBottom: 6 }}>Реклама (Promotion)</div>
                    <textarea
                      className="textarea"
                      value={selected.adsToken}
                      onChange={(e) => setSelectedField({ adsToken: e.target.value })}
                      placeholder="Токен WB Ads (Promotion)"
                    />
                    <div className="row" style={{ marginTop: 8, gap: 8 }}>
                      <button
                        className="btn primary"
                        onClick={async () => {
                          const t = selected.adsToken.trim()
                          const checks = {
                            ...(selected.tokenChecks ?? {}),
                            checkedAtMs: Date.now(),
                          } as NonNullable<WbAccount['tokenChecks']>

                          const errors: string[] = []

                          try {
                            await validateAdsToken(t)
                            checks.adsPromotion = true
                          } catch (e: any) {
                            checks.adsPromotion = false
                            errors.push(`Promotion: ${fmtErr(e)}`)
                          }

                          // Media часть может быть недоступна у некоторых кабинетов.
                          try {
                            await getMediaCampaignCount(t)
                            checks.adsMedia = true
                          } catch (e: any) {
                            checks.adsMedia = false
                            errors.push(`Media: ${fmtErr(e)}`)
                          }

                          setSelectedField({ tokenChecks: checks })

                          const parts: string[] = []
                          parts.push(`${checks.adsPromotion ? '✅' : '❌'} promotion`)
                          parts.push(`${checks.adsMedia ? '✅' : '❌'} media`)
                          push(parts.join(' • '))
                          if (errors.length > 0) push(errors.slice(0, 2).join(' | '))
                        }}
                        disabled={!selected.adsToken.trim()}
                      >
                        Проверить
                      </button>
                    </div>
                  </div>
                </div>

                <div className="row" style={{ marginTop: 12, justifyContent: 'flex-end', gap: 8 }}>
                  <button className="btn" onClick={commitAndClose}>
                    Сохранить
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
